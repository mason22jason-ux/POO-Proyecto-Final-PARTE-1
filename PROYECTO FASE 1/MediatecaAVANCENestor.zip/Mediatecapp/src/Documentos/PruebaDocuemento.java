package Documentos;

public class PruebaDocuemento {

    public static void main(String[] args) {

        Documento libro = new Documento(
                "Don Quijote",
                "Miguel de Cervantes",
                "Libro",
                "123456789",
                5,
                "Editorial Española"
        );

        libro.mostrarInformacion();

    }

}