package Documentos;

public class Documento {

    String titulo;
    String autor;
    String tipoDocumento;
    String isbn;
    int cantidad;
    String editorial;

    public Documento(String titulo, String autor, String tipoDocumento, String isbn, int cantidad, String editorial) {

        this.titulo = titulo;
        this.autor = autor;
        this.tipoDocumento = tipoDocumento;
        this.isbn = isbn;
        this.cantidad = cantidad;
        this.editorial = editorial;

    }

    public void mostrarInformacion() {

        System.out.println("Título: " + titulo);
        System.out.println("Autor: " + autor);
        System.out.println("Tipo: " + tipoDocumento);
        System.out.println("ISBN: " + isbn);
        System.out.println("Cantidad: " + cantidad);
        System.out.println("Editorial: " + editorial);

    }

}
    
    
    
    
    
    
    
    
    
    
