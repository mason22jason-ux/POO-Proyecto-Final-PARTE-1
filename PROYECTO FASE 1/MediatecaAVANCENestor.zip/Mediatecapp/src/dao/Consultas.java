/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import Documentos.Documento;
/**
 *
 * @author nesto
 */
public class Consultas {

    public List<Documento> Consulta(String filtro) {
        
        //creacion del array
        List<Documento> listaResultados = new ArrayList<>();
        
        // consulta sql
        String sql = "SELECT * FROM material WHERE titulo LIKE ? OR codigo LIKE ?";

        // conexion a bd
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            // El comodín % permite buscar coincidencias parciales (ej: "Quijote" encuentra "Don Quijote")
            String busqueda = "%" + filtro + "%";
            ps.setString(1, busqueda);
            ps.setString(2, busqueda);

            // se ejecuta la consulta para obtener los resultados
            ResultSet rs = ps.executeQuery();

            // se recorre meintras encuentre resultados
            while (rs.next()) {
                
                // Extraemos los datos que sí existen en la tabla 'material'
                String titulo = rs.getString("titulo");
                String tipo = rs.getString("tipo");
                String codigo = rs.getString("codigo");
                
                //se crea el objeto tipo docuemnto, llenado de datos temporales
                Documento doc = new Documento(
                    titulo,               // titulo
                    "Autor no asignado",  // autor (Dato temporal)
                    tipo,                 // tipoDocumento
                    codigo,               // isbn (usamos el código de la DB)
                    1,                    // cantidad (Dato temporal)
                    "Editorial N/A"       // editorial (Dato temporal)
                );

                //guardando el objeto en la lista
                listaResultados.add(doc);
            }

        } catch (SQLException e) {
            System.out.println("Error al consultar: " + e.getMessage());
        }

        // devuelve la lista con todos los documentos encontrados
        return listaResultados;
    }
}
