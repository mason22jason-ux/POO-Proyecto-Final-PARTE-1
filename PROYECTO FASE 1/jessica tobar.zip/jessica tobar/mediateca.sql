CREATE DATABASE MediatecaDB;

USE MediatecaDB;

CREATE TABLE Documentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(100),
    autor VARCHAR(100),
    tipoDocumento VARCHAR(50),
    isbn VARCHAR(50),
    cantidad INT,
    editorial VARCHAR(100)
);