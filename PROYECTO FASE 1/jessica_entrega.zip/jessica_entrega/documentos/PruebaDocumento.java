package Documentos;

public class PruebaDocumento {

    public static void main(String[] args) {

        Documento libro = new Documento(
                "Don Quijote",
                "Miguel de Cervantes",
                "Libro",
                "123456789",
                5,
                "Editorial Española",
                "Disponible"
        );

        libro.mostrarInformacion();

    }

}
