Integrante 2 - Registro de documentos y ejemplares

Archivos incluidos:
- Documento.java
- PruebaDocumento.java
- Mediateca.sql
